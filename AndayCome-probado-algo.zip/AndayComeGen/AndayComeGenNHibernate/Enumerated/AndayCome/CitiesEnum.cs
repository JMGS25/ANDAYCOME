
using System;

namespace AndayComeGenNHibernate.Enumerated.AndayCome
{
public enum CitiesEnum { alic=1, valencia=2 };
}
