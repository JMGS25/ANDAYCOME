

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using AndayComeGenNHibernate.Exceptions;

using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;


namespace AndayComeGenNHibernate.CEN.AndayCome
{
/*
 *      Definition of the class RouteCEN
 *
 */
public partial class RouteCEN
{
private IRouteCAD _IRouteCAD;

public RouteCEN()
{
        this._IRouteCAD = new RouteCAD ();
}

public RouteCEN(IRouteCAD _IRouteCAD)
{
        this._IRouteCAD = _IRouteCAD;
}

public IRouteCAD get_IRouteCAD ()
{
        return this._IRouteCAD;
}

public void Modify (int p_Route_OID, Nullable<DateTime> p_start_date, Nullable<DateTime> p_end_date, string p_photo, string p_description, string p_name)
{
        RouteEN routeEN = null;

        //Initialized RouteEN
        routeEN = new RouteEN ();
        routeEN.Id = p_Route_OID;
        routeEN.Start_date = p_start_date;
        routeEN.End_date = p_end_date;
        routeEN.Photo = p_photo;
        routeEN.Description = p_description;
        routeEN.Name = p_name;
        //Call to RouteCAD

        _IRouteCAD.Modify (routeEN);
}

public void Destroy (int id
                     )
{
        _IRouteCAD.Destroy (id);
}

public void AddClient (int p_Route_OID, System.Collections.Generic.IList<string> p_clients_OIDs)
{
        //Call to RouteCAD

        _IRouteCAD.AddClient (p_Route_OID, p_clients_OIDs);
}
public void RemoveClient (int p_Route_OID, System.Collections.Generic.IList<string> p_clients_OIDs)
{
        //Call to RouteCAD

        _IRouteCAD.RemoveClient (p_Route_OID, p_clients_OIDs);
}
public System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RouteEN> FilterByCity (string p_city)
{
        return _IRouteCAD.FilterByCity (p_city);
}
}
}
