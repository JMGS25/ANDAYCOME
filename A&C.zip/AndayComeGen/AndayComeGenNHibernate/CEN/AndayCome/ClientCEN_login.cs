
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using AndayComeGenNHibernate.Exceptions;
using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;


/*PROTECTED REGION ID(usingAndayComeGenNHibernate.CEN.AndayCome_Client_login) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace AndayComeGenNHibernate.CEN.AndayCome
{
public partial class ClientCEN
{
        string result = null;
        UsuarioEN en = _IUsuarioCAD.ReadOIDDefault(p_Usuario_OID);

        if (en != null && en.Pass.Equals(Utils.Util.GetEncondeMD5 (p_pass)))
                result = this.GetToken(en.email);

        return result;
}
}
