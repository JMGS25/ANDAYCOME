
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using AndayComeGenNHibernate.Exceptions;
using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;


/*PROTECTED REGION ID(usingAndayComeGenNHibernate.CEN.AndayCome_Payment_processpay) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace AndayComeGenNHibernate.CEN.AndayCome
{
public partial class PaymentCEN
{
public void Processpay (int p_oid)
{
        /*PROTECTED REGION ID(AndayComeGenNHibernate.CEN.AndayCome_Payment_processpay) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Processpay() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
