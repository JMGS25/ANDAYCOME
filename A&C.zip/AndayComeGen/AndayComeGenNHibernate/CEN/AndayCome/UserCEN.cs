

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using AndayComeGenNHibernate.Exceptions;

using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;


namespace AndayComeGenNHibernate.CEN.AndayCome
{
/*
 *      Definition of the class UserCEN
 *
 */
public partial class UserCEN
{
private IUserCAD _IUserCAD;

public UserCEN()
{
        this._IUserCAD = new UserCAD ();
}

public UserCEN(IUserCAD _IUserCAD)
{
        this._IUserCAD = _IUserCAD;
}

public IUserCAD get_IUserCAD ()
{
        return this._IUserCAD;
}

public int New_ (int p_tel, string p_photo, String p_pass, int p_country, string p_email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum p_language)
{
        UserEN userEN = null;
        int oid;

        //Initialized UserEN
        userEN = new UserEN ();
        userEN.Tel = p_tel;

        userEN.Photo = p_photo;

        userEN.Pass = Utils.Util.GetEncondeMD5 (p_pass);


        if (p_country != -1) {
                // El argumento p_country -> Property country es oid = false
                // Lista de oids id
                userEN.Country = new AndayComeGenNHibernate.EN.AndayCome.CountryEN ();
                userEN.Country.Id = p_country;
        }

        userEN.Email = p_email;

        userEN.Language = p_language;

        //Call to UserCAD

        oid = _IUserCAD.New_ (userEN);
        return oid;
}

public void Modify (int p_User_OID, int p_tel, string p_photo, String p_pass, string p_email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum p_language)
{
        UserEN userEN = null;

        //Initialized UserEN
        userEN = new UserEN ();
        userEN.Id = p_User_OID;
        userEN.Tel = p_tel;
        userEN.Photo = p_photo;
        userEN.Pass = Utils.Util.GetEncondeMD5 (p_pass);
        userEN.Email = p_email;
        userEN.Language = p_language;
        //Call to UserCAD

        _IUserCAD.Modify (userEN);
}

public void Destroy (int id
                     )
{
        _IUserCAD.Destroy (id);
}

public string Login (int p_User_OID, string p_pass)
{
        string result = null;
        UserEN en = _IUserCAD.ReadOIDDefault (p_User_OID);

        if (en != null && en.Pass.Equals (Utils.Util.GetEncondeMD5 (p_pass)))
                result = this.GetToken (en.Id);

        return result;
}




private string Encode (int id)
{
        var payload = new Dictionary<string, object>(){
                { "id", id }
        };
        string token = Jose.JWT.Encode (payload, Utils.Util.getKey (), Jose.JwsAlgorithm.HS256);

        return token;
}

public string GetToken (int id)
{
        UserEN en = _IUserCAD.ReadOIDDefault (id);
        string token = Encode (en.Id);

        return token;
}
public int CheckToken (string token)
{
        int result = -1;

        try
        {
                string decodedToken = Utils.Util.Decode (token);



                int id = (int)ObtenerID (decodedToken);

                UserEN en = _IUserCAD.ReadOIDDefault (id);

                if (en != null && ((long)en.Id).Equals (ObtenerID (decodedToken))
                    ) {
                        result = id;
                }
                else throw new ModelException ("El token es incorrecto");
        } catch (Exception e)
        {
                throw new ModelException ("El token es incorrecto");
        }

        return result;
}


public long ObtenerID (string decodedToken)
{
        try
        {
                Dictionary<string, object> results = JsonConvert.DeserializeObject<Dictionary<string, object> >(decodedToken);
                long id = (long)results ["id"];
                return id;
        }
        catch
        {
                throw new Exception ("El token enviado no es correcto");
        }
}
}
}
