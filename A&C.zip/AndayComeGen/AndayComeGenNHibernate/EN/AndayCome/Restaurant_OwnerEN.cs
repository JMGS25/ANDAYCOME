
using System;
// Definición clase Restaurant_OwnerEN
namespace AndayComeGenNHibernate.EN.AndayCome
{
public partial class Restaurant_OwnerEN                                                                     : AndayComeGenNHibernate.EN.AndayCome.UserEN


{
/**
 *	Atributo restaurants
 */
private System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN> restaurants;






public virtual System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN> Restaurants {
        get { return restaurants; } set { restaurants = value;  }
}





public Restaurant_OwnerEN() : base ()
{
        restaurants = new System.Collections.Generic.List<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN>();
}



public Restaurant_OwnerEN(int id, System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN> restaurants
                          , int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language
                          )
{
        this.init (Id, restaurants, tel, photo, pass, country, email, language);
}


public Restaurant_OwnerEN(Restaurant_OwnerEN restaurant_Owner)
{
        this.init (Id, restaurant_Owner.Restaurants, restaurant_Owner.Tel, restaurant_Owner.Photo, restaurant_Owner.Pass, restaurant_Owner.Country, restaurant_Owner.Email, restaurant_Owner.Language);
}

private void init (int id
                   , System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN> restaurants, int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language)
{
        this.Id = id;


        this.Restaurants = restaurants;

        this.Tel = tel;

        this.Photo = photo;

        this.Pass = pass;

        this.Country = country;

        this.Email = email;

        this.Language = language;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        Restaurant_OwnerEN t = obj as Restaurant_OwnerEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
