
using System;
// Definición clase AdminEN
namespace AndayComeGenNHibernate.EN.AndayCome
{
public partial class AdminEN                                                                        : AndayComeGenNHibernate.EN.AndayCome.UserEN


{
public AdminEN() : base ()
{
}



public AdminEN(int id,
               int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language
               )
{
        this.init (Id, tel, photo, pass, country, email, language);
}


public AdminEN(AdminEN admin)
{
        this.init (Id, admin.Tel, admin.Photo, admin.Pass, admin.Country, admin.Email, admin.Language);
}

private void init (int id
                   , int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language)
{
        this.Id = id;


        this.Tel = tel;

        this.Photo = photo;

        this.Pass = pass;

        this.Country = country;

        this.Email = email;

        this.Language = language;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        AdminEN t = obj as AdminEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
