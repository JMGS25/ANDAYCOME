
using System;
// Definición clase UserEN
namespace AndayComeGenNHibernate.EN.AndayCome
{
public partial class UserEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo tel
 */
private int tel;



/**
 *	Atributo photo
 */
private string photo;



/**
 *	Atributo pass
 */
private String pass;



/**
 *	Atributo country
 */
private AndayComeGenNHibernate.EN.AndayCome.CountryEN country;



/**
 *	Atributo email
 */
private string email;



/**
 *	Atributo language
 */
private AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual int Tel {
        get { return tel; } set { tel = value;  }
}



public virtual string Photo {
        get { return photo; } set { photo = value;  }
}



public virtual String Pass {
        get { return pass; } set { pass = value;  }
}



public virtual AndayComeGenNHibernate.EN.AndayCome.CountryEN Country {
        get { return country; } set { country = value;  }
}



public virtual string Email {
        get { return email; } set { email = value;  }
}



public virtual AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum Language {
        get { return language; } set { language = value;  }
}





public UserEN()
{
}



public UserEN(int id, int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language
              )
{
        this.init (Id, tel, photo, pass, country, email, language);
}


public UserEN(UserEN user)
{
        this.init (Id, user.Tel, user.Photo, user.Pass, user.Country, user.Email, user.Language);
}

private void init (int id
                   , int tel, string photo, String pass, AndayComeGenNHibernate.EN.AndayCome.CountryEN country, string email, AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum language)
{
        this.Id = id;


        this.Tel = tel;

        this.Photo = photo;

        this.Pass = pass;

        this.Country = country;

        this.Email = email;

        this.Language = language;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        UserEN t = obj as UserEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
