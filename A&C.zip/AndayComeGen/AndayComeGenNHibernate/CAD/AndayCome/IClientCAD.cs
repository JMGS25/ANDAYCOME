
using System;
using AndayComeGenNHibernate.EN.AndayCome;

namespace AndayComeGenNHibernate.CAD.AndayCome
{
public partial interface IClientCAD
{
ClientEN ReadOIDDefault (int id
                         );

void ModifyDefault (ClientEN client);

System.Collections.Generic.IList<ClientEN> ReadAllDefault (int first, int size);



int New_ (ClientEN client);

void Modify (ClientEN client);


void Destroy (int id
              );
}
}
