
using System;
using AndayComeGenNHibernate.EN.AndayCome;

namespace AndayComeGenNHibernate.CAD.AndayCome
{
public partial interface IBookingCAD
{
BookingEN ReadOIDDefault (int id
                          );

void ModifyDefault (BookingEN booking);

System.Collections.Generic.IList<BookingEN> ReadAllDefault (int first, int size);



int New_ (BookingEN booking);

void Modify (BookingEN booking);


void Destroy (int id
              );
}
}
