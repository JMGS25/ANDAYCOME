
using System;
using AndayComeGenNHibernate.EN.AndayCome;

namespace AndayComeGenNHibernate.CAD.AndayCome
{
public partial interface IRestaurant_OwnerCAD
{
Restaurant_OwnerEN ReadOIDDefault (int id
                                   );

void ModifyDefault (Restaurant_OwnerEN restaurant_Owner);

System.Collections.Generic.IList<Restaurant_OwnerEN> ReadAllDefault (int first, int size);



int New_ (Restaurant_OwnerEN restaurant_Owner);

void Modify (Restaurant_OwnerEN restaurant_Owner);


void Destroy (int id
              );
}
}
