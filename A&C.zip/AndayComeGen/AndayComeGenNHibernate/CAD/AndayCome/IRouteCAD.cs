
using System;
using AndayComeGenNHibernate.EN.AndayCome;

namespace AndayComeGenNHibernate.CAD.AndayCome
{
public partial interface IRouteCAD
{
RouteEN ReadOIDDefault (int id
                        );

void ModifyDefault (RouteEN route);

System.Collections.Generic.IList<RouteEN> ReadAllDefault (int first, int size);



int New_ (RouteEN route);

void Modify (RouteEN route);


void Destroy (int id
              );






void AddClient (int p_Route_OID, System.Collections.Generic.IList<string> p_clients_OIDs);

void RemoveClient (int p_Route_OID, System.Collections.Generic.IList<string> p_clients_OIDs);

System.Collections.Generic.IList<AndayComeGenNHibernate.EN.AndayCome.RouteEN> FilterByCity (string p_city);
}
}
