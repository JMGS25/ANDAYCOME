
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using System.Collections.Generic;
using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;
using AndayComeGenNHibernate.CEN.AndayCome;



/*PROTECTED REGION ID(usingAndayComeGenNHibernate.CP.AndayCome_Route_new_) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace AndayComeGenNHibernate.CP.AndayCome
{
public partial class RouteCP : BasicCP
{
public AndayComeGenNHibernate.EN.AndayCome.RouteEN New_ (string p_creator, int p_countries, System.Collections.Generic.IList<int> p_restaurants, Nullable<DateTime> p_start_date, Nullable<DateTime> p_end_date, string p_photo, string p_description, string p_name)
{
        /*PROTECTED REGION ID(AndayComeGenNHibernate.CP.AndayCome_Route_new_) ENABLED START*/

        IRouteCAD routeCAD = null;
        RouteCEN routeCEN = null;

        AndayComeGenNHibernate.EN.AndayCome.RouteEN result = null;


        try
        {
                SessionInitializeTransaction ();
                routeCAD = new RouteCAD (session);
                routeCEN = new  RouteCEN (routeCAD);




                int oid;
                //Initialized RouteEN
                RouteEN routeEN;
                routeEN = new RouteEN ();

                if (p_creator != -1) {
                        routeEN.Creator = new AndayComeGenNHibernate.EN.AndayCome.ClientEN ();
                        routeEN.Creator.Id = p_creator;
                }


                if (p_countries != -1) {
                        routeEN.Countries = new AndayComeGenNHibernate.EN.AndayCome.CountryEN ();
                        routeEN.Countries.Id = p_countries;
                }


                routeEN.Restaurants = new System.Collections.Generic.List<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN>();
                if (p_restaurants != null) {
                        for (int item : p_restaurants) {
                                AndayComeGenNHibernate.EN.AndayCome.RestaurantEN en = new AndayComeGenNHibernate.EN.AndayCome.RestaurantEN ();
                                en.Id = item;
                                routeEN.Restaurants ().Add (en);
                        }
                }

                else{
                        routeEN.Restaurants = new System.Collections.Generic.List<AndayComeGenNHibernate.EN.AndayCome.RestaurantEN>();
                }

                routeEN.Start_date = p_start_date;

                routeEN.End_date = p_end_date;

                routeEN.Photo = p_photo;

                routeEN.Desc = p_desc;

                routeEN.Name = p_name;

                //Call to RouteCAD

                oid = routeCAD.New_ (routeEN);
                result = routeCAD.ReadOIDDefault (oid);



                SessionCommit ();
        }
        catch (Exception ex)
        {
                SessionRollBack ();
                throw ex;
        }
        finally
        {
                SessionClose ();
        }
        return result;


        /*PROTECTED REGION END*/
}
}
}
