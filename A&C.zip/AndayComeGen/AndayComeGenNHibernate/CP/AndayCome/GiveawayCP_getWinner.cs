
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using System.Collections.Generic;
using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;
using AndayComeGenNHibernate.CEN.AndayCome;



/*PROTECTED REGION ID(usingAndayComeGenNHibernate.CP.AndayCome_Giveaway_getWinner) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace AndayComeGenNHibernate.CP.AndayCome
{
public partial class GiveawayCP : BasicCP
{
public void GetWinner (int p_oid)
{
        /*PROTECTED REGION ID(AndayComeGenNHibernate.CP.AndayCome_Giveaway_getWinner) ENABLED START*/

        IGiveawayCAD giveawayCAD = null;
        GiveawayCEN giveawayCEN = null;



        try
        {
                SessionInitializeTransaction ();
                giveawayCAD = new GiveawayCAD (session);
                giveawayCEN = new  GiveawayCEN (giveawayCAD);



                // Write here your custom transaction ...

                throw new NotImplementedException ("Method GetWinner() not yet implemented.");



                SessionCommit ();
        }
        catch (Exception ex)
        {
                SessionRollBack ();
                throw ex;
        }
        finally
        {
                SessionClose ();
        }


        /*PROTECTED REGION END*/
}
}
}
