
using System;

namespace AndayComeGenNHibernate.Enumerated.AndayCome
{
public enum LanguageEnum { spanish=1, english=2 };
}
