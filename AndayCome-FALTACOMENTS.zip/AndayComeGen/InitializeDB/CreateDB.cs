
/*PROTECTED REGION ID(CreateDB_imports) ENABLED START*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using AndayComeGenNHibernate.EN.AndayCome;
using AndayComeGenNHibernate.CEN.AndayCome;
using AndayComeGenNHibernate.CAD.AndayCome;
using AndayComeGenNHibernate.CP.AndayCome;

/*PROTECTED REGION END*/
namespace InitializeDB
{
public class CreateDB
{
public static void Create (string databaseArg, string userArg, string passArg)
{
        String database = databaseArg;
        String user = userArg;
        String pass = passArg;

        // Conex DB
        SqlConnection cnn = new SqlConnection (@"Server=(local)\sqlexpress; database=master; integrated security=yes");

        // Order T-SQL create user
        String createUser = @"IF NOT EXISTS(SELECT name FROM master.dbo.syslogins WHERE name = '" + user + @"')
            BEGIN
                CREATE LOGIN ["                                                                                                                                     + user + @"] WITH PASSWORD=N'" + pass + @"', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
            END"                                                                                                                                                                                                                                                                                    ;

        //Order delete user if exist
        String deleteDataBase = @"if exists(select * from sys.databases where name = '" + database + "') DROP DATABASE [" + database + "]";
        //Order create databas
        string createBD = "CREATE DATABASE " + database;
        //Order associate user with database
        String associatedUser = @"USE [" + database + "];CREATE USER [" + user + "] FOR LOGIN [" + user + "];USE [" + database + "];EXEC sp_addrolemember N'db_owner', N'" + user + "'";
        SqlCommand cmd = null;

        try
        {
                // Open conex
                cnn.Open ();

                //Create user in SQLSERVER
                cmd = new SqlCommand (createUser, cnn);
                cmd.ExecuteNonQuery ();

                //DELETE database if exist
                cmd = new SqlCommand (deleteDataBase, cnn);
                cmd.ExecuteNonQuery ();

                //CREATE DB
                cmd = new SqlCommand (createBD, cnn);
                cmd.ExecuteNonQuery ();

                //Associate user with db
                cmd = new SqlCommand (associatedUser, cnn);
                cmd.ExecuteNonQuery ();

                System.Console.WriteLine ("DataBase create sucessfully..");
        }
        catch (Exception ex)
        {
                throw ex;
        }
        finally
        {
                if (cnn.State == ConnectionState.Open) {
                        cnn.Close ();
                }
        }
}

public static void InitializeData ()
{
        /*PROTECTED REGION ID(initializeDataMethod) ENABLED START*/
        try
        {
                // Insert the initilizations of entities using the CEN classes

                // p.e. CustomerCEN customer = new CustomerCEN();
                // customer.New_ (p_user:"user", p_password:"1234");

                CountryCEN country = new CountryCEN ();
                int c_oid = country.New_ (AndayComeGenNHibernate.Enumerated.AndayCome.CitiesEnum.alic);
                int c_oid2 = country.New_ (AndayComeGenNHibernate.Enumerated.AndayCome.CitiesEnum.valencia);

                //dependen de country
                //###########################
                ClientCEN cliente = new ClientCEN ();


                string cli1_oid = cliente.New_ (123456789, "photo1", "1234", c_oid, "juanma25092001@gmail.com", AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum.spanish, "usuario1", false);
                string cli2_oid = cliente.New_ (123456789, "photo2", "12345", c_oid, "ianbuku21@gmail.com", AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum.spanish, "usuario2", true);
                string cli3_oid = cliente.New_ (123456789, "photo3", "123456", c_oid, "usuario3@gmail.com", AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum.english, "usuario3", false);


                Console.WriteLine ("Cliente 1: " + cli1_oid);
                Console.WriteLine ("Cliente 2: " + cli2_oid);
                Console.WriteLine ("Cliente 3: " + cli3_oid);
                Console.WriteLine ("---------------------");

                Console.WriteLine ("Creamos un admin:");
                AdminCEN adminCEN = new AdminCEN ();
                string admin1_oid = adminCEN.New_ (123456789, "photo1", "4321", c_oid, "ib5@gmail.com", AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum.spanish, "Ian");

                Restaurant_OwnerCEN rest_own1 = new Restaurant_OwnerCEN ();

                string res_onw_oid = rest_own1.New_ (123456789, "photo1", "4321", c_oid, "ib50@gmail.com", AndayComeGenNHibernate.Enumerated.AndayCome.LanguageEnum.spanish, "Ian_mi_nenita_20");
                //------------------------------------


                //depende de un cliente
                //###########################

                PaymentCEN pay = new PaymentCEN ();
                pay.New_ (cli1_oid, true, DateTime.Today);

                ComentariosCEN coment = new ComentariosCEN ();
                coment.New_ ("comentario generico", cli2_oid, DateTime.Today);

                RatesCEN rateCEN = new RatesCEN ();
                int oid_rate1 = rateCEN.New_(cli1_oid, 5);
                int oid_rate2 = rateCEN.New_(cli2_oid, 5);

                RestaurantCEN restaurantCEN = new RestaurantCEN ();
                int rest_oid = restaurantCEN.New_ (res_onw_oid, "menu generico", "photo_res", "Bar matusalem", "calle false 123", 32);
                int rest_oid2 = restaurantCEN.New_ (res_onw_oid, "menu generico", "photo_res", "Bar angosto", "calle false 123", 32);
                int rest_oid3 = restaurantCEN.New_ (res_onw_oid, "menu generico", "photo_res", "Bar ancho", "calle false 123", 32);
                int rest_oid4 = restaurantCEN.New_ (res_onw_oid, "menu generico", "photo_res", "Bar no incluido en el tag", "calle false 123", 32);
                //------------------------------------


                //depende de un cliente y de un restaurante
                //###########################
                TicketCEN tic = new TicketCEN ();
                tic.New_ (cli3_oid, rest_oid, DateTime.Today, 3.4f);

                BookingCP book = new BookingCP ();
                BookingEN book_oid = book.New_ (rest_oid, cli3_oid, DateTime.Now, DateTime.Now, 4);
                //------------------------------------


                //depende de un cliente, un restaurante, una reserva, y una country
                //###########################
                RouteCEN route = new RouteCEN ();
                int ruta1 = route.New_ (cli2_oid, c_oid, new List<int> { rest_oid }, DateTime.Now, DateTime.Now, "photo1", "una ruta generica", "ruta de rutas ruteando1");
                int ruta2 = route.New_ (cli2_oid, c_oid, new List<int> { rest_oid }, DateTime.Now, DateTime.Now, "photo1", "una ruta generica2", "ruta de rutas ruteando2");
                int ruta3 = route.New_ (cli2_oid, c_oid2, new List<int> { rest_oid }, DateTime.Now, DateTime.Now, "photo1", "una ruta generica3", "ruta de rutas ruteando3");
                //------------------------------------


                //No depende
                //###########################
                WallCEN wall = new WallCEN ();
                wall.New_ ();

                GiveawayCEN giveawayCEN = new GiveawayCEN ();
                int oid_sorteo = giveawayCEN.New_ (20, true, "pin o chapa");

                TagsCEN tag = new TagsCEN ();
                string idTag1 = tag.New_ ("Italiano");
                string idTag2 = tag.New_ ("Picante");
                //------------------------------------


                //PRUEBA DE FILTERBYCITY : filtro de rutas por ciudad
                //filtramos
                RouteCEN routeCEN = new RouteCEN ();
                IList<RouteEN> listRutas = routeCEN.FilterByCity (AndayComeGenNHibernate.Enumerated.AndayCome.CitiesEnum.alic);
                foreach (RouteEN ruta in listRutas) {
                        Console.WriteLine ("Tienen esta ciudad las rutas: " + ruta.Name);
                }
                //FIN DE PRUEBA



                //PRUEBA DE FILTERBYTAG

                IList<int> restaurantes = new List<int>();
                restaurantes.Add (rest_oid);
                restaurantes.Add (rest_oid2);
                restaurantes.Add (rest_oid3);
                tag.AddRestaurant (idTag1, restaurantes);
                //filtramos
                IList<RestaurantEN> listRes = restaurantCEN.FilterByTag (idTag1);
                foreach (RestaurantEN res in listRes) {
                        Console.WriteLine ("Tienen este tag (italiano): " + res.Name);
                }
                //FIN DE PRUEBA



                //PRUEBA DE GETWINNER
                IList<string> clientes = new List<string>();
                clientes.Add (cli1_oid);
                clientes.Add (cli2_oid);

                giveawayCEN.AddClient (oid_sorteo, clientes);
                GiveawayCP giveawayCP = new GiveawayCP ();
                giveawayCP.GetWinner (oid_sorteo);
                GiveawayEN giveawayEN = giveawayCEN.ReadOID (oid_sorteo);

                Console.WriteLine ("El ganador del sorteo es: " + giveawayEN.Winner);
                //FIN DE PRUEBA


                //PRUEBA DE OBTENER CONTACTO
                Console.WriteLine ("Obtenemos el contacto del admin " + admin1_oid + ": " + adminCEN.ObtenerContacto (admin1_oid));
                //FIN DE PRUEBA



                //PRUEBA FILTERBYRESTAURANT (route)

                //relacionamos rutas con restaurantes
                IList<int> restaurant_ids = new List<int>();
                restaurant_ids.Add (rest_oid4);

                routeCEN.AddRestaurant (ruta2, restaurant_ids);
                routeCEN.AddRestaurant (ruta1, restaurant_ids);


                IList<RouteEN> restor = new List<RouteEN>();
                RestaurantEN restaurantEN = restaurantCEN.ReadOID (rest_oid4);

                restor = routeCEN.FilterByRestaurant (restaurantEN.Name);
                foreach (RouteEN ruta in restor) {
                        Console.WriteLine ("Tienen el restaurante las rutas: " + ruta.Name);
                }

                //FIN DE PRUEBA

                //PRUEBA DE VISUALIZAR RUTA
                Console.WriteLine("Probamos el m�todo custom VisualizarRuta: ");
                Console.WriteLine("Ruta 1: " + route.VisualizarRuta(ruta1));
                Console.WriteLine("Ruta 2: " + route.VisualizarRuta(ruta2));
                Console.WriteLine("Ruta 3: " + route.VisualizarRuta(ruta3));
                Console.WriteLine("---------------------");
                //FIN DE PRUEBA



                //PRUEBA DE FILTERBYRATE(Restaurant)
                //relacionamos las rates con los restaurantes
                //obtenemos restaurante sy metemos en una lista
                IList<int> restaurant_ids_rates = new List<int>(); //oid de restaurantes
                restaurant_ids_rates.Add(rest_oid2); 
                restaurant_ids_rates.Add(rest_oid3);
                //relacionamos restauantes con una valoracion
                rateCEN.RateRestaurant(oid_rate2, restaurant_ids_rates);
                IList<int> restaurant_rates = new List<int>();
                restaurant_rates.Add(rest_oid);
                restaurant_rates.Add(rest_oid4);
                rateCEN.RateRestaurant(oid_rate1, restaurant_rates);
                //probar filtro
                IList<RestaurantEN> restsEN = new List<RestaurantEN>();
                restsEN = restaurantCEN.FilterbyRate(4);
                foreach (RestaurantEN res in restsEN)
                {
                    Console.WriteLine("Los restaurantes que superan la nota media son: " + res.Name);
                }
                //FIN DE PRUEBA

                //PRUEBA DE CREAR EMAIL (creemos que tiene que ser CP --> preguntar)
                //restaurantCEN.AddClient(rest_oid, clientes);
                //restaurantCEN.SendMail(rest_oid, "HOLA", "CUERPO");
                /*PROTECTED REGION END*/
            }
            catch (Exception ex)
        {
                System.Console.WriteLine (ex.InnerException);
                throw ex;
        }
}
}
}
